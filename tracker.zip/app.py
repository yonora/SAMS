from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from dotenv import load_dotenv
import os

load_dotenv()  # Load environment variables from .env file

app = Flask(__name__)
# Add a secret key for Flask sessions and flash messages
app.secret_key = os.getenv('SECRET_KEY', 'fallback_secret_key_for_development')

# Configure MySQL connection using environment variables
def get_db_connection():
    return mysql.connector.connect(
        host=os.getenv('DB_HOST'),
        user=os.getenv('DB_USER'),
        password=os.getenv('DB_PASSWORD'),
        database=os.getenv('DB_NAME')
    )

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/attendance', methods=['GET', 'POST'])
def attendance():
    db = get_db_connection()
    cursor = db.cursor()
    if request.method == 'POST':
        # Handle form submission from modal
        return redirect(url_for('attendance'))
    cursor.execute("SELECT * FROM attendance")
    data = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('attendance.html', data=data)

@app.route('/attendance/add', methods=['POST'])
def add_attendance():
    if request.method == 'POST':
        student_name = request.form['student_name']
        date = request.form['date']
        status = request.form['status']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("INSERT INTO attendance (student_name, date, status) VALUES (%s, %s, %s)", (student_name, date, status))
        db.commit()
        cursor.close()
        db.close()
        flash('Attendance record successfully added!', 'success')
    return redirect(url_for('attendance'))

@app.route('/attendance/edit/<int:id>', methods=['POST'])
def edit_attendance(id):
    if request.method == 'POST':
        student_name = request.form['student_name']
        date = request.form['date']
        status = request.form['status']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("UPDATE attendance SET student_name=%s, date=%s, status=%s WHERE id=%s", (student_name, date, status, id))
        db.commit()
        cursor.close()
        db.close()
        flash('Attendance record successfully updated!', 'success')
    return redirect(url_for('attendance'))

@app.route('/attendance/delete/<int:id>')
def delete_attendance(id):
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("DELETE FROM attendance WHERE id=%s", (id,))
    db.commit()
    cursor.close()
    db.close()
    flash('Attendance record successfully deleted!', 'success')
    return redirect(url_for('attendance'))

@app.route('/exam', methods=['GET', 'POST'])
def exam():
    db = get_db_connection()
    cursor = db.cursor()
    if request.method == 'POST':
        # Handle form submission from modal
        return redirect(url_for('exam'))
    cursor.execute("SELECT * FROM exam")
    data = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('exam.html', data=data)

@app.route('/exam/add', methods=['POST'])
def add_exam():
    if request.method == 'POST':
        student_name = request.form['student_name']
        exam_date = request.form['exam_date']
        score = request.form['score']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("INSERT INTO exam (student_name, exam_date, score) VALUES (%s, %s, %s)", (student_name, exam_date, score))
        db.commit()
        cursor.close()
        db.close()
        flash('Exam record successfully added!', 'success')
    return redirect(url_for('exam'))

@app.route('/exam/edit/<int:id>', methods=['POST'])
def edit_exam(id):
    if request.method == 'POST':
        student_name = request.form['student_name']
        exam_date = request.form['exam_date']
        score = request.form['score']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("UPDATE exam SET student_name=%s, exam_date=%s, score=%s WHERE id=%s", (student_name, exam_date, score, id))
        db.commit()
        cursor.close()
        db.close()
        flash('Exam record successfully updated!', 'success')
    return redirect(url_for('exam'))

@app.route('/exam/delete/<int:id>')
def delete_exam(id):
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("DELETE FROM exam WHERE id=%s", (id,))
    db.commit()
    cursor.close()
    db.close()
    flash('Exam record successfully deleted!', 'success')
    return redirect(url_for('exam'))

@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    db = get_db_connection()
    cursor = db.cursor()
    if request.method == 'POST':
        # Handle form submission from modal
        return redirect(url_for('quiz'))
    cursor.execute("SELECT * FROM quiz")
    data = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('quiz.html', data=data)

@app.route('/quiz/add', methods=['POST'])
def add_quiz():
    if request.method == 'POST':
        student_name = request.form['student_name']
        quiz_date = request.form['quiz_date']
        score = request.form['score']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("INSERT INTO quiz (student_name, quiz_date, score) VALUES (%s, %s, %s)", (student_name, quiz_date, score))
        db.commit()
        cursor.close()
        db.close()
        flash('Quiz record successfully added!', 'success')
    return redirect(url_for('quiz'))

@app.route('/quiz/edit/<int:id>', methods=['POST'])
def edit_quiz(id):
    if request.method == 'POST':
        student_name = request.form['student_name']
        quiz_date = request.form['quiz_date']
        score = request.form['score']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("UPDATE quiz SET student_name=%s, quiz_date=%s, score=%s WHERE id=%s", (student_name, quiz_date, score, id))
        db.commit()
        cursor.close()
        db.close()
        flash('Quiz record successfully updated!', 'success')
    return redirect(url_for('quiz'))

@app.route('/quiz/delete/<int:id>')
def delete_quiz(id):
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("DELETE FROM quiz WHERE id=%s", (id,))
    db.commit()
    cursor.close()
    db.close()
    flash('Quiz record successfully deleted!', 'success')
    return redirect(url_for('quiz'))

if __name__ == '__main__':
    app.run(debug=True)
